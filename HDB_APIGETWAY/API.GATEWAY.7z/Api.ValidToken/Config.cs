﻿using System.Collections.Generic;
using IdentityServer4.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;

namespace Api.ValidToken
{
    public static class Config
    {

        public static IEnumerable<ApiResource> GetAllApiResources()
        {
            return new List<ApiResource>
            {
                new ApiResource("HDBANKMOBILE","HDBANK MOBILE"),
                new ApiResource("HDBANKSCOPE","HDBANK SCOPE") 
            };
        }

        public static IEnumerable<Client> GetClients([FromServices]IConfiguration configuration)
        {
            string clSecrets = Startup.StaticConfig.GetSection("ClientSecrets").Value;
            string allowScope = Startup.StaticConfig.GetSection("AllowedScopes").Value;
            string clId = Startup.StaticConfig.GetSection("ClientId").Value;
            return new List<Client>
            {
                new Client
                {
                    ClientId = clId,
                    AllowedGrantTypes = GrantTypes.ClientCredentials,
                    ClientSecrets =
                    {
                        new Secret(clSecrets.Sha256())
                    },
                    AllowedScopes = {"HDBANKMOBILE","HDBANKSCOPE" },
                    AccessTokenLifetime =28800,
                   
                }
            };
        }
    }
}
